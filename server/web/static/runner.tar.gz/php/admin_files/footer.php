</div>
	</div>
		<DIV id="footer" class="clearfix" >
			  <DIV id="footer_midbar">&nbsp;</DIV>
			  <DIV id="company_content_container">
			    <DIV id="global_footer" class="clearfix">
			      <DIV id="logo_box">Devaldi</DIV>
		         
			       <UL style="padding-top:0.3em;padding-left:0px;">
			        <H4><A href="http://flexpaper.devaldi.com">FlexPaper</A></H4>
		
			      </UL>
		
			      <UL style="padding-top:0.3em;padding-left:40px;">
			        <H4><A href="http://flexpaper.devaldi.com/download.htm">Buy</A></H4>
			        <LI style="padding-left:0px;"><A href="http://flexpaper.devaldi.com/download/">License</A></LI>
			        <LI style="padding-left:0px;"><A href="http://flexpaper.devaldi.com/plugins.htm">Plug-ins</A></LI>
			        
			      </UL>
		          
		          <UL style="padding-top:0.3em;padding-left:40px;">
			        <H4><A href="http://flexpaper.devaldi.com/about.htm">Contact</A></H4>
			        <LI style="padding-left:0px;"><A href="http://www.twitter.com/flexpaper">Twitter</A></LI>
			      </UL>
		          
		          <UL style="padding-top:0.3em;padding-left:40px;">
			        <H4><A href="http://flexpaper.devaldi.com/docs.htm">Help</A></H4>
			        <LI style="padding-left:0px;"><A href="http://flexpaper.devaldi.com/docs.htm">Tutorial</A></LI>
		            <LI style="padding-left:0px;"><A href="http://flexpaper.devaldi.com/docs_api.jsp">API Docs</A></LI>
			      </UL>
			    
		          <UL style="padding-top:0.3em;padding-left:40px;">
			        <H4>About</H4>
			        <LI style="padding-left:0px;"><A href="http://flexpaper.devaldi.com/about.htm">Devaldi Ltd</A></LI>
			      </UL>
				</DIV>
			    <DIV id="copyright_statement">©2010-2011 DEVALDI LTD ALL RIGHTS RESERVED.
			    </DIV>
			  </DIV>
			</DIV>
	</div>
   </body> 
</html> 