#!/usr/bin/env python
import platform
import commands
import os
import sys

#OSTT Support Product List
#Note:If creating a new test project. Please add the test project name to PRODUCT_LIST
PRODUCT_LIST='tablet_jellybean,phone_jellybean,camera_bkb,camera_JellyBean,camera_JellyBean_ft,gallery_bkb,gallery_JellyBean,gallery_JellyBean_FT,ivi'

#OpenCV is an excellent library for Computer Vision
OPENCV = ('libcv.so.2.1','libcvaux.so.2.1','libcxcore.so.2.1','libcxts.so.2.1','libhighgui.so.2.1','libml.so.2.1')
ADB_SHELL = 'adb shell '
ADB_VERSION = 'adb version'
WHICH_ADB = 'which adb'
#Local system information defination
JAVA_VERSION = 'java -version'
OS_VERSION1004 = 'Ubuntu 10.04'
OS_VERSION1104 = 'Ubuntu 11.04'
OS_VERSION1204 = 'Ubuntu 12.04'
JDK6 = '1.6'
JDK7 = '1.7'
ADB_VERSION_INFO = ['Android Debug Bridge version 1.0.26','Android Debug Bridge version 1.0.29','Android Debug Bridge version 1.0.31']
LOCAL_LIB  = '/usr/local/lib/'


class Setup(object):
    '''
    Check PC environment.
    Init device setting.
    '''
    def setup(self):
        #Check script folder exists.
        product = self.extSys_argvs()
        currentPath = sys.path[0]
        scriptPath = '%s/%s'%(currentPath,product)
        if not os.path.exists(scriptPath):
            print 'ERROR! ' + product + ' script folder is not exist!'
            sys.exit()

        #1.Common setup of system
        sys_setup = SystemSetup()
        sys_setup.setup()

        #2. Special setup of device
        self.productSetup(product)

        #3. Reboot the device              
        commands.getoutput(ADB_SHELL + 'reboot')

        

    def productSetup(self,product):
        print '==========Special device Setup=========='
        path = os.path.abspath(os.path.join(os.getcwd(), '%s%s%s%s'%(product,'/',product,'_setup.py')))
        print path 
        if not os.path.exists(path):
            return              
        try:
            special_setup = __import__('%s%s%s%s'%(product,'.',product,'_setup'),fromlist=["*"])
            special_setup.ProductSetup().setup(product)
            print 'Special device setup success!'
            print '------------------------------------------------------'
        except Exception ,e:
            print e
            print 'Special device setup failed!'
            print '------------------------------------------------------' 


    #check commands and get product name
    def extSys_argvs(self):
        strArg = ''.join(sys.argv)
        if strArg.find('-p') == -1:
	    self.showUsage()
            #print 'Please input command like: python setup.py -p product_name'
            #print 'ProductName:like bkb,oms25 etc.'
            sys.exit()
        else:
            argPIndex = sys.argv.index('-p')
            if argPIndex != 1:
		self.showUsage()
                #print 'Please input python setup.py -p product_name'
                #print 'Product:bkb oms25 etc.'
                sys.exit()
            else:
		if argPIndex == len(sys.argv)-1:
		    self.showUsage()
		    sys.exit()
                elif PRODUCT_LIST.find(sys.argv[argPIndex + 1]) == -1:
                    print 'Not support product:' + sys.argv[argPIndex + 1]
                    print 'ProductName:like bkb,oms25 etc.'
                    sys.exit()
            return sys.argv[argPIndex + 1]
    
    def showUsage(cls):
        print 'Usage:'
        print 'python setup.py [-p productname]'
        print '-p productname : product name after -p parameter'
        print '                 e.g.'
        print '                 python setup.py -p product_name'



class SystemSetup(object):
    def setup(self):
        self.currentPath = sys.path[0]
        print self.currentPath
        #Verify Operating system. JDK version. Adb version.SDK MonkeyRunner path
        self.checkTestEnvs()

    #check if Linux OS, JDK, ADB, and Monkeyrunner work
    def checkTestEnvs(self) :
        print '==========Common set up of system=========='
        #check liunx os version
        print '1.Check os version'
        systemInfo = platform.system()
        print 'OS version:' + systemInfo
        if systemInfo != 'Linux':
            print 'ERROR!  Please install Linux Ubuntu 10.04 or 11.04 12.04'
            sys.exit()
        linuxVersion = commands.getoutput('cat /etc/issue')
        print linuxVersion
        if linuxVersion.find(OS_VERSION1004) == -1 and linuxVersion.find(OS_VERSION1104) and linuxVersion.find(OS_VERSION1204):
            print 'ERROR!  Please install Linux Ubuntu 10.04 or 11.04, 12.04'
            #sys.exit()
        print 'SUCCESS!'
        print '------------------------------------------------------'
        
        #check jdk version
        print '2.Check jdk version'
        jdkVersion = commands.getoutput(JAVA_VERSION)
        print jdkVersion
        if jdkVersion.find(JDK6) == -1 and jdkVersion.find(JDK7) == -1:
            print 'ERROR!  Please install jdk 1.6.x or jdk1.7.x'
            sys.exit()
        print 'SUCCESS!'
        print '------------------------------------------------------'
        
        #check adb set to environment varible
        print '3.Check adb set to environment variable'
        adbEnv = commands.getoutput(WHICH_ADB)
        print adbEnv
        if adbEnv.find('/home') and adbEnv.find('adb') == -1:
            print 'ERROR!  Please set adb to environment variable!'
            sys.exit()
        print 'SUCCESS!'
        print '------------------------------------------------------'
        
        #check adb version
        print '4.Check adb version...'
        adbVer = commands.getoutput(ADB_VERSION)
        print adbVer
        if not adbVer in ADB_VERSION_INFO:
            print 'ERROR!  Please use adb version 2.3.3 or later '
            sys.exit()
        print 'SUCCESS!'
        print '------------------------------------------------------'
        
        #check monkeyrunner set to environment
        print '5.Check monkeyrunner set to environment variable'
        monkeyrunnerEnv = commands.getoutput('which monkeyrunner')
        print monkeyrunnerEnv
        if monkeyrunnerEnv.find('/home') and monkeyrunnerEnv.find('monkeyrunner') == -1:
            print 'ERROR!  Please set monkeyrunner to environment variable'
            sys.exit()
        print 'SUCCESS!'
        print '------------------------------------------------------'

        print '6.Check openCV'
        for f in OPENCV:
            files = '%s%s'%(LOCAL_LIB,f) 
            if not os.path.exists(files):
                self.installOpenCV()
                print 'Opencv Install finished!'
                break
        print 'SUCCESS!'
        print '------------------------------------------------------\n'
        print 'Environment install finished!'
        print '======================================================\n'

                
    def installOpenCV(self):
        print 'Install openCV...'
        bits = commands.getoutput("getconf LONG_BIT")
        cmd = []
        for lib in OPENCV:
            cmd.append('%s/libs/dependence/opencv%sbit/%s ' % (self.currentPath,bits,lib))
        os.popen('%s%s%s' % ('sudo cp ',''.join(cmd),LOCAL_LIB))
        os.popen('%s %s' % ('cd',LOCAL_LIB))
        #os.popen('%s %s' % ('sudo ln -s ','libcvaux.so.2.1 libcvaux.so'))
        os.popen('%s%s%s%s%s' % ('sudo ln -s ',LOCAL_LIB,'libcvaux.so.2.1 ',LOCAL_LIB,'libcvaux.so'))
        #os.popen('%s %s' % ('sudo ln -s ','libcv.so.2.1 libcv.so'))
        os.popen('%s%s%s%s%s' % ('sudo ln -s ',LOCAL_LIB,'libcv.so.2.1 ',LOCAL_LIB,'libcv.so'))
        #os.popen('%s %s' % ('sudo ln -s ','libcxcore.so.2.1 libcxcore.so'))
        os.popen('%s%s%s%s%s' % ('sudo ln -s ',LOCAL_LIB,'libcxcore.so.2.1 ',LOCAL_LIB,'libcxcore.so'))
        
        #os.popen('%s %s' % ('sudo ln -s ','libcxts.so.2.1 libcxts.so'))
        os.popen('%s%s%s%s%s' % ('sudo ln -s ',LOCAL_LIB,'libcxts.so.2.1 ',LOCAL_LIB,'libcxts.so'))
        
        #os.popen('%s %s' % ('sudo ln -s ','libhighgui.so.2.1 libhighgui.so'))
        os.popen('%s%s%s%s%s' % ('sudo ln -s ',LOCAL_LIB,'libhighgui.so.2.1 ',LOCAL_LIB,'libhighgui.so'))
             
        #os.popen('%s %s' % ('sudo ln -s ','libml.so.2.1 libml.so'))
        os.popen('%s%s%s%s%s' % ('sudo ln -s ',LOCAL_LIB,'libml.so.2.1 ',LOCAL_LIB,'libml.so'))
        os.popen('%s %s '% ('sudo ','ldconfig'))
        print 'Env Install finished!'
    



if (__name__ == '__main__'):
    setup = Setup()
    setup.setup()


