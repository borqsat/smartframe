import sys,os
ext_jar_path = '%s%s%s' % (os.path.dirname(__file__),os.sep,'recognition.jar')
sys.path.append(ext_jar_path)
from org.sikuli.script import Settings
Settings.InfoLogs = False
