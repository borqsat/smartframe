'''

:copyright: Copyright 2006-2009 by Oliver Schoenborn, all rights reserved.
:license: BSD, see LICENSE.txt for details.

'''

def getRootTopicSpec():
    '''If using kwargs protocol, then root topic takes no args.'''
    argsDocs = {}
    reqdArgs = ()
    return argsDocs, reqdArgs

