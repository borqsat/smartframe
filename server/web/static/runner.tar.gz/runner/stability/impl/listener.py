'''
EpyDoc
@version: $id$
@author: U{borqsat<www.borqs.com>}
@see: null
'''

from libs.pubsub import pub
from builder import TestBuilder
from resulthandler import ResultHandler

def collectResult(func):
    def wrap(*args, **argkw):
        func(*args, **argkw)
        if True:
            content = (func.__name__,args)
            pub.sendMessage('collectresult',info=content)
        return func
    return wrap

def onTopicResult(info=None,path=None,sessionStatus=None):
    '''sort test session's result.
    Keyword arguments:
    kwags -- should specify the data structure of argument.
    types: sessioncreate,caseresult
    info: (methodname,test,error) (methodname,test) info[0]:addStart,addStop,addSuccess,addFailure,addError
    '''
    ResultHandler.handle(info,path,sessionStatus)
		
def onTopicGui(guiMsg):
    '''Topic for updating UI'''
    pass

def onTopicMemoryTrack():
    '''Topic for memory monitor'''
    pass

#mapper = {'collectresult':onTopicResult,
#            'gui':onTopicGui,
#            'memorytrack':onTopicMemoryTrack}

#print 'init pubsub listener begin:'
handler = ResultHandler()
pub.subscribe(handler.handle,'collectresult')
#pub.subscribe(reconnect,'reconnecttopic')

